package com.eis.lab_5_1.bean;

public class Employee {
	int id;
	String name;
	double salary;
	Designations designation;
	InsuranceSchemes insuranceScheme;
	
	public Employee(int id, String name, double salary, Designations designation, InsuranceSchemes insuranceScheme) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", designation=" + designation
				+ ", insuranceScheme=" + insuranceScheme + "]";
	}
}
