package com.eis.lab_5_1.bean;

public enum Designations {
	SystemAssociate,Programmer,Manager,Clerk;
}
