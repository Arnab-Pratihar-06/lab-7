package com.eis.lab_5_1.bean;

public enum InsuranceSchemes {
	SchemeA,SchemeB,SchemeC,NoSchemes
}
