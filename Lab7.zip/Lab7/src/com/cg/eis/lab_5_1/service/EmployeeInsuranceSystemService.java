package com.cg.eis.lab_5_1.service;

import com.eis.lab_5_1.bean.Designations;
import com.eis.lab_5_1.bean.Employee;
import com.eis.lab_5_1.bean.InsuranceSchemes;

public class EmployeeInsuranceSystemService implements EmployeeService{
	private Employee empList[];

	public EmployeeInsuranceSystemService(int noOfEmp) {
		this.empList=new Employee[noOfEmp];
	}

	public void addEmployeeDetails(int id,String name,double salary,Designations designation,InsuranceSchemes insuranceScheme) {
		if(id>0 && id<this.empList.length) {
			this.empList[id]=new Employee(id,name,salary,designation,insuranceScheme);
		}
	}
	public InsuranceSchemes showInsuranceSchemes(int id,double salary,Designations designation) {
		if(id>0 && id<this.empList.length)
		{
			if(salary>=40000 && designation ==Designations.Manager)
			{
				return InsuranceSchemes.SchemeA;
			}
			else if(salary>20000 && salary <40000 && designation ==Designations.Programmer)
			{
				return InsuranceSchemes.SchemeB;
			}
			else if(salary>5000 && salary<20000 && designation==Designations.SystemAssociate )
			{
				return InsuranceSchemes.SchemeC;
			}
			else if(salary<5000 && designation ==Designations.Clerk)
			{
				return  InsuranceSchemes.NoSchemes;
			}
		}
		return null;
	}
	
	public String dispEmployeeDetails(int id) {
		if(id>0 && id<this.empList.length)
			return this.empList[id].toString();
		return null;
	}
}
