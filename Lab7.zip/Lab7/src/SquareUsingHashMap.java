import java.util.HashMap;
import java.util.Scanner;

import com.sun.javafx.collections.MappingChange.Map;

public class SquareUsingHashMap {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array:");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter array elements:");
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("========");
		System.out.println("The contents of the array:");
		for(int i:arr) {
			System.out.println(i);
		}
		System.out.println("=========");
		System.out.println("The contents of the map: ");
		HashMap<Integer, Double> m = getSquares(arr);
		for(int i : m.keySet()) {
			System.out.println(i+"-"+m.get(i));
		}
	}
	public static HashMap<Integer, Double> getSquares(int arr[]){
		HashMap<Integer, Double> m = new HashMap<Integer, Double>();
		for(int n : arr)
			m.put(n, calcSq(n));
		return m;
	}
	public static double calcSq(int n) {
		return n*n;
	}
}
