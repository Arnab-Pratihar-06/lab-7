import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RemoveListFromOtherList {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		List<String>list1=new ArrayList<>();
		List<String>list2=new ArrayList<>();
		
		String s1,s2;
		int flag=1,ch;
		while(flag==1) {
			System.out.println("Enter content in the First List : ");
			s1=sc.next();
			list1.add(s1);
			System.out.println("Entered.\n Do you want to enter anymore           yes=1 ; no=0 " );
			ch=sc.nextInt();
			flag=ch;
		}
		
		flag=1;
		while(flag==1) {
			System.out.println("Enter content in the Second List : ");
			s2=sc.next();
			list2.add(s2);
			System.out.println("Entered.\n Do you want to enter anymore         yes=1 ; no=0 ");
			ch=sc.nextInt();
			flag=ch;
		}
		System.out.println("==========");
		System.out.println("Before removal.....");
		System.out.println("Contents of the list1 :");
		for(String s : list1) {
			System.out.println(s);
		}
		
		System.out.println("Contents of the list2 :");
		for(String s:list2) {
			System.out.println(s);
		}
	}
	public static List removeElements(List<String>list1,List<String>list2) {
		list1.removeAll(list2);
		return list1;
	}
}
